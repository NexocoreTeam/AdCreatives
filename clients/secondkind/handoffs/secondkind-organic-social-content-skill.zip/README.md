# SecondKind Organic Social Content Skill

Portable skill package for the organic social team.

## What This Is

This skill helps an AI assistant generate SecondKind organic social:

- Content ideas
- Hooks
- TikTok and Reels scripts
- Captions
- Carousel outlines
- Creator POV briefs
- Weekly or monthly content calendars

It is built around the 2026 SecondKind strategy:

- Gut health as the daily foundation
- Postbiotics as the technology
- The Real-Life 90-Day Gut Reset as the consistency offer
- Premium, restrained, clinically literate voice
- Organic-first creator POV mechanics

## Install

Copy this folder into your AI assistant's skills directory:

```text
skills/secondkind-organic-social-content/
```

The folder to copy is:

```text
secondkind-organic-social-content/
```

## Example Prompts

```text
Use the SecondKind organic social skill to give me 20 TikTok ideas for Gut Balance.
```

```text
Use the SecondKind organic social skill to write 10 creator POV scripts around probiotic fatigue.
```

```text
Use the SecondKind organic social skill to build a 30-day Instagram content calendar.
```

```text
Use the SecondKind organic social skill to turn the 90-day gut reset into carousel concepts.
```

## Notes

This is a strategy and copy skill, not legal review. Any health-related claims should still go through the brand's normal compliance process before publishing.
