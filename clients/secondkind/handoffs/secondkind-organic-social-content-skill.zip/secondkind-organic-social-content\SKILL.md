---
name: secondkind-organic-social-content
description: "Generate SecondKind organic social content ideas, hooks, scripts, captions, UGC briefs, carousels, and content calendars using the 2026 gut-foundation and Real-Life 90-Day Gut Reset strategy. Use for TikTok, Instagram Reels, Instagram captions, LinkedIn, YouTube Shorts, creator POV concepts, organic content pillars, and monthly content planning for SecondKind."
---

# SecondKind Organic Social Content

Use this skill to create organic social strategy and copy for SecondKind. The job is not to write generic supplement content. The job is to turn SecondKind into a daily gut-foundation brand: real symptoms first, gut as the system behind them, postbiotics as the payoff, and the Real-Life 90-Day Gut Reset as the consistency offer.

## Load First

Read `references/secondkind-organic-strategy.md` before producing final content.

If the task involves a specific format, also read:

- `references/content-formats.md` for platform formats, output shapes, and templates.
- `references/compliance-guardrails.md` for claim language and risky phrasing.

## Core Positioning

Default center of gravity:

SecondKind is a postbiotic-first daily wellness system that supports the gut, the foundation behind how the whole body feels.

Master promise:

Support the system behind how you feel every day: your gut.

Default copy ladder:

1. Name the real-life feeling.
2. Reframe it as a gut-foundation issue.
3. Explain that probiotics are the process and postbiotics are the payoff.
4. Present Gut Balance as the daily routine.
5. Push the Real-Life 90-Day Gut Reset or simple daily consistency.

## Organic Social Workflow

1. Identify the platform and format.
2. Pick one audience tension, not three.
3. Start with a lived moment: bloated after eating clean, foggy by 3pm, irregular while doing everything right, feeling off-routine, tired of probiotic disappointment.
4. Reframe the moment through the gut as a daily foundation.
5. Use postbiotics as the mechanism, but keep the opening human.
6. Make the routine feel doable: two capsules, no cleanse, no restrictive protocol, no wellness overwhelm.
7. End with a soft organic CTA: save this, start with your gut, give your gut 90 days, build the routine, see what is included.

## High-Value Content Pillars

Use these pillars to build idea banks and calendars:

- Real-life symptom reframes: bloating, brain fog, sluggishness, irregularity, stress, poor sleep, feeling off.
- Probiotic fatigue: people tried live bacteria, fermented foods, restrictive diets, and still felt no durable change.
- Postbiotics explained simply: probiotics are the process, postbiotics are the payoff.
- Daily foundation logic: gut health is not a once-in-a-while fix; it works every day, so support it every day.
- 90-day consistency: one bottle starts the change, three months gives the body a real reset window.
- Founder story: Danielle tried everything; the useful angle is the recognition of the same lived symptoms, not melodrama.
- Routine POV: the easiest gut routine is the one someone will actually stick with.
- Science without hype: patented postbiotic ingredients, shelf stability, no live-culture survival problem, clinically literate voice.
- Myth correction: gut health should simplify life, not become a complicated wellness protocol.

## Output Standards

For idea generation, include:

- Concept title.
- Platform and format.
- Audience tension.
- Hook.
- Content beat outline.
- Visual direction.
- Caption or script.
- CTA.
- Claim/compliance note when relevant.

For copywriting, produce multiple options with distinct angles, not tiny rewrites of the same line.

For calendars, balance formats:

- 35% creator POV or routine content.
- 25% educational myth/reframe content.
- 20% symptom-led empathy content.
- 10% founder/proof/story content.
- 10% offer/routine/reset content.

## Voice

Use a premium, restrained, clinically literate, direct voice.

Prefer:

- Short declarative sentences.
- Calm confidence.
- Clear mechanism language.
- Human symptom language before science language.
- Creator-native phrasing when writing for TikTok/Reels.

Avoid:

- Hype.
- Miracle language.
- All-caps urgency.
- Overexplaining in captions.
- Luxury-for-luxury copy.
- Competitor names in customer-facing copy.
- Generic supplement claims like "less bloat" when the ad is trying to explain why SecondKind is different.

## Approved Organic Angles

Use and adapt these:

- I stopped treating gut health like a random fix.
- I gave my gut 90 days of consistency.
- This is the easiest gut routine I have actually stuck with.
- I did not need a complicated protocol. I needed a routine.
- Your gut works every day. Support it every day.
- Most people do not need another random supplement. They need a routine they can stick with.
- Probiotics are the process. Postbiotics are the payoff.
- Stop chasing bacteria. Start supporting balance.
- A gut reset for real life, not another complicated wellness protocol.

## Visual Direction

For organic POV, favor true first-person creator mechanics:

- Hand/product/routine in frame.
- Morning counter, bag, desk, kitchen, travel pouch, smoothie, salad, water glass, supplement shelf.
- Platform-native, imperfect, useful.
- Not polished third-person lifestyle.
- Not sterile counter still-life unless the concept specifically needs a product proof shot.

For SecondKind visuals:

- Premium editorial restraint.
- Warm natural light.
- Dark amber jar and black lid.
- Warm off-white, stone, charcoal, restrained green, marigold only when Mood Balance is involved.
- Avoid all-caps text, drop shadows, loose tracking, non-brand type styles, and overbusy layouts.

## Compliance

Use structure/function phrasing.

Say:

- supports digestion
- supports regularity
- supports gut lining
- supports immune resilience
- supports calm, sleep quality, stress response, focus, and emotional balance
- helps you feel lighter, clearer, and more in rhythm

Avoid:

- controls mood
- fixes sleep
- treats anxiety
- cures brain fog
- eliminates bloating
- guaranteed results
- medical treatment language

Do not promise that one bottle completes a transformation. The durable story is consistency.

## Quick Prompt Template

When asked for content, internally fill this in before writing:

- Platform:
- Format:
- Audience symptom/tension:
- Awareness stage:
- Pillar:
- Mechanism depth:
- CTA strength:
- Assets available:
- Offer mention: none / soft / Real-Life 90-Day Gut Reset

Then produce the content in the user's requested format.

## Final Check

Before finalizing, ask:

- Does this open with a human moment instead of a supplement claim?
- Does it ladder back to the gut as the daily foundation?
- Is postbiotic education simple enough for a cold audience?
- Does it sound like SecondKind, not a generic wellness brand?
- Are claims compliant and non-medical?
- Is the format native to the platform?
