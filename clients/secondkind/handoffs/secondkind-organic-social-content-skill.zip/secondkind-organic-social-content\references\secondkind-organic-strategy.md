# SecondKind Organic Strategy Reference

## Strategic Shift

Phase-one research remains valid: ICPs, pain points, probiotic fatigue, competitor gaps, and postbiotic mechanism still matter. The new strategy changes hierarchy, not the underlying research.

Old center of gravity:

A premium postbiotic supplement for bloating, digestion, and gut-brain balance.

New center of gravity:

A postbiotic-first daily wellness system that supports the gut, the foundation behind how the whole body feels.

This makes the brand more must-have. The gut is not one wellness category among many. It is the system behind everyday function.

## Master Promise

Support the system behind how you feel every day: your gut.

Everything should ladder back to this. Bloating and digestion are entry points. Whole-body rhythm is the larger promise.

## Copy Hierarchy

Use this order in most organic concepts:

1. Name the real-life feeling.
2. Reframe it as a gut-foundation issue.
3. Explain that probiotics are the process and postbiotics are the payoff.
4. Present SecondKind as the daily routine.
5. Push 90-day consistency only when it fits naturally.

## Real-Life 90-Day Gut Reset

The strongest acquisition offer is The Real-Life 90-Day Gut Reset.

Core components:

- 3 bottles of Gut Balance.
- 90-day reset guide.
- Simple what-to-expect timeline.
- Bloating or trigger tracker.
- Gut-friendly meal or snack prompts.
- Weekly reset tips or SMS/email check-ins.
- Travel and routine tips.
- Guidance for missed days.
- 90-day guarantee only if approved by client/legal.

Use this as a value stack, not a coupon. If using buy 2, get 1 free, it should support the reset logic and not lead as discount language.

## Audience Tensions

Use these as content starting points:

- I eat clean and still feel bloated.
- I tried probiotics and felt nothing.
- I do everything right but still feel foggy or sluggish.
- I am tired of complicated wellness protocols.
- I want gut support but do not want to build my life around it.
- I start supplements and fall off because nothing feels clear.
- I do not need a cleanse; I need a routine.
- My body feels off and I cannot quite name why.

## Core ICPs

Keep the core personas available, but do not over-label them in content:

- Done-Everything Danielle: tried clean eating, probiotics, elimination diets, and still gets bloated/foggy.
- Immune-Anxious Isaac: cares about resilience, getting sick less often, performance, and proof.
- New-Normal New Mom Natalie: wants to feel like herself again without a complicated protocol.
- Functional-Curious Practitioner Paul: needs clinical logic and credible mechanism language.
- Burnout Biohacker Brandon: wants a mechanism he missed, not another wellness trend.
- Perimenopause Paula: wants grounded support for rhythm, comfort, and feeling steady.

## Mechanism

Postbiotics are the beneficial compounds good bacteria are meant to produce. SecondKind delivers those compounds directly instead of relying on fragile live bacteria to survive digestion and colonize.

Portable lines:

- Probiotics are the process. Postbiotics are the payoff.
- Skip the middleman.
- Stop chasing bacteria. Start supporting balance.
- Postbiotics are the beneficial compounds good bacteria are meant to create.
- No live cultures trying to survive digestion.
- Works after digestion, not before it.

## Proof Points

Use proof carefully and only when appropriate:

- Gut Balance uses patented postbiotic ingredients including Totipro, EpiCor, and Bereum.
- Postbiotics are shelf-stable because they are not live bacteria.
- The mechanism avoids the live-culture survival problem.
- Ingredient studies support digestion, gut comfort, regularity, gut lining, immune resilience, and quality-of-life related outcomes.

Do not overclaim. Do not imply disease treatment.

## Founder Story

Remy's wife Danielle struggled with bloating, low energy, and brain fog after their first child. They tried probiotics, elimination diets, and many supplement paths. The useful content angle is not melodrama; it is recognition: the same "I tried everything" pattern the customer knows.

Use founder story for trust and resonance, not as a miracle testimonial.

## Brand Voice

Voice: science-credible, editorially restrained, quietly confident.

Tone: calm, precise, grounded, clinically literate, direct, warm without hype.

Do:

- Lead with the real feeling.
- Use short declarative lines.
- Teach one useful idea at a time.
- Keep claims structure/function compliant.
- Let restraint signal premium.

Do not:

- Use miracle language.
- Use all caps.
- Use aggressive challenger language.
- Name competitors in customer-facing copy.
- Make the product sound like a cure.
- Use generic wellness fluff.
