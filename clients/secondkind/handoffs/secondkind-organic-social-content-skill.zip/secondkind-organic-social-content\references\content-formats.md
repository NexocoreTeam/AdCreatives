# SecondKind Organic Content Formats

## TikTok / Instagram Reels Script

Use this structure:

- On-screen hook: 6-10 words.
- First beat: recognizable lived moment.
- Second beat: gut-foundation reframe.
- Third beat: postbiotic payoff in plain English.
- Fourth beat: routine or 90-day consistency.
- CTA: soft, native, low pressure.

Example shape:

On-screen hook: I stopped treating gut health like a quick fix

Script:

I used to buy a new gut supplement every time I felt bloated.

Then I realized my gut did not need another random fix.

It needed something I could do every day.

SecondKind uses postbiotics: the beneficial compounds probiotics are supposed to create.

No complicated protocol. Just a routine I can actually stick with.

CTA: Give your gut 90 days of consistency.

## Carousel

Use 5-7 slides:

1. Pattern-interrupt headline.
2. Lived symptom or frustration.
3. Reframe through gut foundation.
4. Simple postbiotic explanation.
5. Routine or reset logic.
6. Proof or compliant support point.
7. Save/share/soft CTA.

## Static Organic Post

Best for concise educational reframes:

- Headline.
- 2-4 short body lines.
- One mechanism line.
- Soft CTA.

## Caption

Structure:

- First line: human tension.
- Middle: one reframe.
- Mechanism: one sentence max unless the prompt asks for education.
- Close: routine or saveable takeaway.

Avoid long brand-explainer captions unless the content format is explicitly educational.

## Content Calendar

For weekly planning, use this mix:

- 2 creator POV/routine posts.
- 1 symptom-led empathy post.
- 1 education/myth post.
- 1 proof/founder/ingredient post.
- 1 offer/reset/routine post.

For monthly planning, include:

- Pillar.
- Platform.
- Format.
- Hook.
- Visual direction.
- Caption/script note.
- CTA.
- Funnel role: reach, education, trust, routine, conversion.

## Creator POV Direction

Good scenes:

- Taking Gut Balance before coffee or breakfast.
- Packing Gut Balance before travel.
- Desk drawer routine.
- Kitchen counter with water glass.
- Salad or smoothie lunch POV.
- Evening reset with next-day routine prep.
- Hand holding product, not model posing with product.

Avoid:

- Polished counter still-life as the main concept.
- Third-person wellness lifestyle stock feel.
- Overly perfect morning routine.
- Product floating in empty aesthetic space.
- Heavy text overlays.

## Idea Bank Output Template

For each idea, output:

- Title:
- Platform:
- Format:
- Pillar:
- Audience tension:
- Hook:
- Beats:
- Visual direction:
- Caption/script:
- CTA:
- Compliance note:
