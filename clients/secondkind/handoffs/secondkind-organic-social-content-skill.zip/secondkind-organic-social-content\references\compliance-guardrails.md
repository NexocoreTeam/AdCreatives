# SecondKind Compliance Guardrails

This is not legal review. Use these guardrails to avoid obviously risky supplement claims before client/legal review.

## Safer Claim Language

Use:

- supports digestion
- supports regularity
- supports gut lining
- supports immune resilience
- supports calm
- supports sleep quality
- supports stress response
- supports focus
- supports emotional balance
- helps you feel lighter
- helps you feel clearer
- helps you feel more in rhythm
- helps support everyday gut balance

## Risky Language To Avoid

Avoid:

- controls mood
- fixes sleep
- treats anxiety
- cures brain fog
- eliminates bloating
- prevents illness
- stops inflammation
- heals the gut
- guaranteed results
- clinically proven to cure
- works for everyone
- detoxes your body
- resets hormones

## Before / After Caution

Do not imply medical transformation. If showing routine before/after, frame it around consistency, not cure.

Safer:

Before: random gut fixes.
After: a daily routine I can stick with.

Risky:

Before: bloated and anxious.
After: cured and never bloated again.

## 90-Day Reset Language

Use:

- 90 days of consistency.
- A reset window.
- A daily routine.
- Simple tools to help you stick with it.
- Build better rhythm.

Avoid:

- guaranteed 90-day transformation.
- cure in 90 days.
- eliminate bloating in 90 days.
- fix your gut permanently.

## Competitor Language

Do not name competitors in customer-facing copy. Use category-level language:

- live-bacteria supplements
- traditional probiotics
- the probiotics you tried
- complicated gut protocols
- random supplement switching

## Medical Disclaimer Mindset

When in doubt, make the content educational and structure/function based. Do not diagnose, treat, cure, or prevent disease.
